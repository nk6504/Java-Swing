package Java.Swing.QLKH.Test;

import Java.Swing.QLKH.UI.KhachHangUI;

public class TestKhachHangUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		KhachHangUI ui = new KhachHangUI("Chương trình quản lí khách hàng");
		ui.ShowWindows();
	}

}
