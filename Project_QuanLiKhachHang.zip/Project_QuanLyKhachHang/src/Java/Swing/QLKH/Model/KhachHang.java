package Java.Swing.QLKH.Model;

public class KhachHang {
	private String maKH;
	private String tenKH;
	private String phone;
	private String email;
	private NhomKhachHang nhom;
	
	public KhachHang() {
		super();
	}
	public KhachHang(String maKH, String tenKH, String phone, String email) {
		super();
		this.maKH = maKH;
		this.tenKH = tenKH;
		this.phone = phone;
		this.email = email;
	}
	public String getMaKH() {
		return maKH;
	}
	public void setMaKH(String maKH) {
		this.maKH = maKH;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public NhomKhachHang getNhom() {
		return nhom;
	}
	public void setNhom(NhomKhachHang nhom) {
		this.nhom = nhom;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.tenKH;
	}
}
