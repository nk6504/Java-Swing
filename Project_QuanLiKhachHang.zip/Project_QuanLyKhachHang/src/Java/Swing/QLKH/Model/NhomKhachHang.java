package Java.Swing.QLKH.Model;

import java.util.Vector;

public class NhomKhachHang {
	private String maNhom;
	private String tenNhom;
	private Vector<KhachHang> khachHangs;
	
	public void ThemKhachHang(KhachHang kh)
	{
		this.khachHangs.add(kh);
		kh.setNhom(this); //Khách hàng được đưa vào nhóm nào thì 
		//nhóm đó sẽ biết được có bao nhiêu khách hàng và bản thân khách hàng phải biết được
		//Khách hàng thuộc nhóm nào
	}
	public NhomKhachHang() {
		super();
		this.khachHangs = new Vector<KhachHang>();
	}
	public NhomKhachHang(String maNhom, String tenNhom) {
		super();
		this.maNhom = maNhom;
		this.tenNhom = tenNhom;
		this.khachHangs = new Vector<KhachHang>(); //Cấp phát bộ nhớ cho ds khách hàng
	}
	public String getMaNhom() {
		return maNhom;
	}
	public void setMaNhom(String maNhom) {
		this.maNhom = maNhom;
	}
	public String getTenNhom() {
		return tenNhom;
	}
	public void setTenNhom(String tenNhom) {
		this.tenNhom = tenNhom;
	}
	public Vector<KhachHang> getKhachHangs() {
		return khachHangs;
	}
	public void setKhachHangs(Vector<KhachHang> khachHangs) {
		this.khachHangs = khachHangs;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.tenNhom;
	}
}
