package Java.Swing.QLKH.UI;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.plaf.FileChooserUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;


import Java.Swing.QLKH.Model.KhachHang;
import Java.Swing.QLKH.Model.NhomKhachHang;


public class KhachHangUI extends JFrame {
	DefaultMutableTreeNode root = null;
	JTree treeNhom;

	DefaultTableModel dtm; 
	JTable tblKhachHang;

	JTextField txtMa,txtTen,txtPhone,txtEmail;

	JButton btnLuu,btnXoa;

	ArrayList<NhomKhachHang> dsNhom;
	ArrayList<KhachHang> dsKhach;

	NhomKhachHang nhomSelected = null; 
	
	JMenuBar mnuBar;
	
	JMenu mnuFile;
	JMenu mnuEdit;
	JMenu mnuHelp;
	
	JMenuItem mnuFileOpen;
	JMenuItem mnuFileSave;
	JMenuItem mnuFileExit;
	
	JMenuItem mnuEditCopy;
	JMenuItem mnuEditPaste;
	JMenuItem mnuEditDelete;
	
	JMenuItem mnuHelpGuide;
	JMenuItem mnuHelpAbout;
	
	JFileChooser chooser;
	public KhachHangUI (String title)
	{
		super(title);
		AddControls();
		AddEvents();
		FakeData();
	}
	public void AddControls()
	{
		Container con = getContentPane();
		JPanel pnLeft = new JPanel();
		pnLeft.setPreferredSize(new Dimension(300,0));
		JPanel pnRight = new JPanel();

		JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,pnLeft,pnRight);
		sp.setOneTouchExpandable(true);
		con.setLayout(new BorderLayout());
		con.add(sp,BorderLayout.CENTER);

		pnRight.setLayout(new BorderLayout());
		JPanel pnTopOfRight = new JPanel();
		pnTopOfRight.setPreferredSize(new Dimension(0,350));
		JPanel pnBottomOfRight = new JPanel();
		JSplitPane spRight = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				pnTopOfRight,
				pnBottomOfRight);
		spRight.setOneTouchExpandable(true);
		pnRight.add(spRight,BorderLayout.CENTER);

		pnLeft.setLayout(new BorderLayout());
		root = new DefaultMutableTreeNode("Công ty TNHH MX");
		treeNhom = new JTree(root);
		JScrollPane scTree = new JScrollPane(treeNhom,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pnLeft.add(scTree,BorderLayout.CENTER);
		treeNhom.setShowsRootHandles(true);

		pnTopOfRight.setLayout(new BorderLayout());
		dtm = new DefaultTableModel();
		dtm.addColumn("Mã Khách Hàng");
		dtm.addColumn("Tên Khách Hàng");
		dtm.addColumn("Số Điện Thoại");
		dtm.addColumn("Thư Điện Tử (Email)");
		tblKhachHang = new JTable(dtm);
		JScrollPane scTable = new JScrollPane(tblKhachHang,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pnTopOfRight.add(scTable,BorderLayout.CENTER);

		pnBottomOfRight.setLayout(new BoxLayout(pnBottomOfRight, BoxLayout.Y_AXIS));
		//1. Mã
		JPanel pnMa = new JPanel();
		pnMa.setLayout(new FlowLayout(FlowLayout.LEFT)); //Dồn các lbl, btn về bên trái
		JLabel lblMa = new JLabel("Mã Khách Hàng: ");
		txtMa = new JTextField(20);
		pnMa.add(lblMa);
		pnMa.add(txtMa);
		pnBottomOfRight.add(pnMa);
		//2. Tên
		JPanel pnTen = new JPanel();
		pnTen.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblTen = new JLabel("Tên Khách Hàng: ");
		txtTen = new JTextField(20);
		pnTen.add(lblTen);
		pnTen.add(txtTen);
		pnBottomOfRight.add(pnTen);
		//3. Số điện thoại
		JPanel pnPhone = new JPanel();
		pnPhone.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblPhone = new JLabel("Số Điện Thoại: ");
		txtPhone = new JTextField(20);
		pnPhone.add(lblPhone);
		pnPhone.add(txtPhone);
		pnBottomOfRight.add(pnPhone);
		//4. Email
		JPanel pnEmail = new JPanel();
		pnEmail.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblEmail = new JLabel("Email: ");
		txtEmail = new JTextField(20);
		pnEmail.add(lblEmail);
		pnEmail.add(txtEmail);
		pnBottomOfRight.add(pnEmail);

		lblMa.setPreferredSize(lblTen.getPreferredSize());
		lblPhone.setPreferredSize(lblTen.getPreferredSize());
		lblEmail.setPreferredSize(lblTen.getPreferredSize());

		JPanel pnButton = new JPanel();
		pnButton.setLayout(new FlowLayout(FlowLayout.LEFT));
		btnLuu = new JButton("Lưu Khách Hàng");
		btnXoa = new JButton("Xóa Khách Hàng");
		pnButton.add(btnLuu);
		pnButton.add(btnXoa);
		pnBottomOfRight.add(pnButton);
		
		mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		mnuFile = new JMenu("File");
		mnuBar.add(mnuFile);
		mnuEdit = new JMenu("Edit");
		mnuBar.add(mnuEdit);
		mnuHelp = new JMenu("Help");
		mnuBar.add(mnuHelp);
		
		mnuFileOpen = new JMenuItem("Open");
		mnuFileOpen.setIcon(new ImageIcon("Pictures/Open.png"));
		mnuFile.add(mnuFileOpen);
		mnuFileSave = new JMenuItem("Save");
		mnuFileSave.setIcon(new ImageIcon("Pictures/Save.png"));
		mnuFile.add(mnuFileSave);
		mnuFile.addSeparator();
		mnuFileExit = new JMenuItem("Exit");
		mnuFileExit.setIcon(new ImageIcon("Pictures/Exit.png"));
		mnuFile.add(mnuFileExit);
		
		mnuEditCopy = new JMenuItem("Copy");
		mnuEditCopy.setIcon(new ImageIcon("Pictures/Copy.png"));
		mnuEdit.add(mnuEditCopy);
		mnuEditPaste = new JMenuItem("Paste");
		mnuEditPaste.setIcon(new ImageIcon("Pictures/Paste.png"));
		mnuEdit.add(mnuEditPaste);
		mnuEditDelete = new JMenuItem("Delete");
		mnuEditDelete.setIcon(new ImageIcon("Pictures/Delete.png"));
		mnuEdit.add(mnuEditDelete);
		
		mnuHelpGuide = new JMenuItem("Guide");
		mnuHelpGuide.setIcon(new ImageIcon("Pictures/Guide.png"));
		mnuHelp.add(mnuHelpGuide);
		mnuHelpAbout = new JMenuItem("About");
		mnuHelpAbout.setIcon(new ImageIcon("Pictures/About.png"));
		mnuHelp.add(mnuHelpAbout);
	}
	public void FakeData()
	{
		dsNhom = new ArrayList<NhomKhachHang>();
		NhomKhachHang vip = new NhomKhachHang("N1","Khách Hàng VIP");
		NhomKhachHang tiemNang = new NhomKhachHang("N2","Khách Hàng Tiềm Năng");
		NhomKhachHang khachHangTrungThanh = new NhomKhachHang("N3", "Khách Hàng Trung Thành");
		NhomKhachHang khachHangMoi = new NhomKhachHang("N4","Khách Hàng Mới"); 
		dsNhom.add(vip); 
		dsNhom.add(tiemNang); 
		dsNhom.add(khachHangTrungThanh);
		dsNhom.add(khachHangMoi);

		vip.getKhachHangs().add(new KhachHang("KH001","Nguyễn Thành An","091233445","an123@gmail.com"));
		vip.getKhachHangs().add(new KhachHang("KH002","Trần Thanh Bình","094357843","Binh471@gmail.com"));
		vip.getKhachHangs().add(new KhachHang("KH003","Lê Hoàng Huy Đào","091324844","DDA124@gmail.com"));
		vip.getKhachHangs().add(new KhachHang("KH004","Nguyễn Đình Huy","0347834122","Huy365@gmail.com"));

		tiemNang.getKhachHangs().add(new KhachHang("KH045","Trần Thị Thúy","0932432543","Thuy034@gmail.com"));
		tiemNang.getKhachHangs().add(new KhachHang("KH046","Lê Thành Trung","09334578349","Trung027@gmail.com"));
		tiemNang.getKhachHangs().add(new KhachHang("KH047","Hồ Thị Điệp","0923457833","Diep1204@gmail.com"));
		tiemNang.getKhachHangs().add(new KhachHang("KH048","Trần Thanh Tú","094587345","TuThanh172@gmail.com"));

		khachHangTrungThanh.getKhachHangs().add(new KhachHang("KH179","Vòng Lập Duy","09234375735","Duy192@gmail.com"));
		khachHangTrungThanh.getKhachHangs().add(new KhachHang("KH180","Trần Anh Khang","02394325435","Khang745@gmail.com"));
		khachHangTrungThanh.getKhachHangs().add(new KhachHang("KH181","Ngô Thị Huyền","02348327543","HuyenHu123@gmail.com"));
		khachHangTrungThanh.getKhachHangs().add(new KhachHang("KH182","Võ Tuyết Như","09234758124","NhuT093@gmail.com"));

		khachHangMoi.getKhachHangs().add(new KhachHang("KHM674","Trần Anh Thư","03248324324","Thu0124@gmail.com"));
		khachHangMoi.getKhachHangs().add(new KhachHang("KHM675","Võ Duy Khánh","03248532543","KhanhDuy0788@gmail.com"));
		for(NhomKhachHang nhom : dsNhom)
		{
			DefaultMutableTreeNode nodeNhom = new DefaultMutableTreeNode(nhom); //lấy đối tượng nhom
			root.add(nodeNhom);
			for(KhachHang kh : nhom.getKhachHangs())
			{
				DefaultMutableTreeNode nodeKhachHang = new DefaultMutableTreeNode(kh);
				nodeNhom.add(nodeKhachHang);
			}	
		}
		treeNhom.expandRow(0); //Mở rộng hàng nếu có nút con
	}
	public void AddEvents()
	{
		treeNhom.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) treeNhom.getLastSelectedPathComponent();
				if(selectedNode != null && selectedNode.getLevel() == 1)
				{
					nhomSelected = (NhomKhachHang) selectedNode.getUserObject();
					HienThiDanhSachKhachHangTheoNhom();
				}
			}
		});
		tblKhachHang.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int rowSelected = tblKhachHang.getSelectedRow();
				if(rowSelected == -1)
					return;
				String ma = tblKhachHang.getValueAt(rowSelected, 0) + "";
				String ten = tblKhachHang.getValueAt(rowSelected, 1) + "";
				String phone = tblKhachHang.getValueAt(rowSelected, 2) + "";
				String email = tblKhachHang.getValueAt(rowSelected, 3) + "";
				txtMa.setText(ma);
				txtTen.setText(ten);
				txtPhone.setText(phone);
				txtEmail.setText(email);
			}
		});
		btnLuu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				KhachHang kh = new KhachHang(
						txtMa.getText(),
						txtTen.getText(),
						txtPhone.getText(),
						txtEmail.getText());
				nhomSelected.ThemKhachHang(kh);
			}
		});
		btnXoa.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				XuLiXoa();
			}
		});
		mnuFileExit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				XuLiThoatPhanMem();		
			}
		});
		mnuFileOpen.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				XuLiMoFile();
			}
		});
		mnuFileSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				XuLiLuuFile();
				
			}
		});
	}
	//2 Chức năng này chưa xử lí được
	protected void XuLiLuuFile() {
	}
	protected void XuLiMoFile() {
	}
	protected void XuLiThoatPhanMem() {
		int ret = JOptionPane.showConfirmDialog(null, 
				"Bạn có chắc chắn muốn thoát phần mềm hay không?",
				"Xác nhận Thoát?",
				JOptionPane.YES_NO_OPTION);
		if(ret == JOptionPane.YES_OPTION)
			System.exit(0);
	}
	protected void XuLiXoa() {
		int rowSelected = tblKhachHang.getSelectedRow();
		if(rowSelected == -1)
			return;
		String valueInTable = dtm.getValueAt(rowSelected, 1).toString();
		dtm.removeRow(rowSelected);
		dtm.fireTableDataChanged();
		DefaultTreeModel model = (DefaultTreeModel) treeNhom.getModel();
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
		
		DefaultMutableTreeNode nodeToDelete = findNode(root,valueInTable);
		if(nodeToDelete!=null)
		{
			DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) nodeToDelete.getParent();
			parentNode.remove(nodeToDelete);
			model.nodeStructureChanged(parentNode); //Cập nhật lại Jtree
		}
	}
	//Hàm tìm node trong Jtree theo giá trị
	private DefaultMutableTreeNode findNode(DefaultMutableTreeNode root, String valueInTable) {
		Enumeration<TreeNode> e = root.depthFirstEnumeration();
		while(e.hasMoreElements())
		{
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) e.nextElement();
			if(node.getUserObject().toString().equals(valueInTable))
			{
				return node;
			}
		}
		return null;
	}
	protected void HienThiDanhSachKhachHangTheoNhom() {
		// TODO Auto-generated method stub
		dtm.setRowCount(0); //Xóa dữ liệu cũ đi
		for(KhachHang kh : nhomSelected.getKhachHangs())
		{
			Vector<String> vec = new Vector<String>();
			vec.add(kh.getMaKH());
			vec.add(kh.getTenKH());
			vec.add(kh.getPhone());
			vec.add(kh.getEmail());
			dtm.addRow(vec);
		}
	}
	public void ShowWindows()
	{
		this.setSize(800,600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	//Bổ Sung
	//2. Tạo Menu Lưu danh sách, lưu dữ liệu nhóm khách hàng và khách hàng vào file và
	//Mở file lên
}
