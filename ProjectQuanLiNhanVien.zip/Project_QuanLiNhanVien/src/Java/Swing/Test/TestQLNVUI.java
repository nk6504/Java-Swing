package Java.Swing.Test;

import Java.Swing.model.QuanLiNhanVienUI;

public class TestQLNVUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuanLiNhanVienUI ui = new QuanLiNhanVienUI("Quản lí nhân viên");
		ui.ShowWindows();
	}

}
