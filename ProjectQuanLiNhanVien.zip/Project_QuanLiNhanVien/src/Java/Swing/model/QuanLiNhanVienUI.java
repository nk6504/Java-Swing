package Java.Swing.model;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

public class QuanLiNhanVienUI extends JFrame {
	JComboBox<PhongBan> cboPhongBan;
	JList<NhanVien> listNhanVien;
	JTextField txtMa,txtTen,txtNgayVaoLam,txtNamSinh;
	JButton btnLuu, btnXoa,btnThoat;
	ArrayList<PhongBan> dsPhongBan;
	ArrayList<NhanVien> dsNhanVienTheoPhongBan;
	
	
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	
	PhongBan pbSelected = null;
	NhanVien nvSelected = null;
	public QuanLiNhanVienUI(String title)
	{
		super(title);
		AddControls();
		AddEvents();
		FakeData();
	}
	private Date FromStringToDate(String d)
	{
		try
		{
			java.util.Date utildate = sdf.parse(d);
			Date sqldate = new Date(utildate.getTime());
			return sqldate;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return null;
	}
	public void FakeData()
	{
		//Khởi tạo từng đối tượng PhongBan, nhập liệu cho nó và add vào DsPhongBan
		//Sau đó duyệt trong dsPhongBan và add vào CboPhongBan 
		
		dsPhongBan = new ArrayList<PhongBan>();
		PhongBan phtgv = new PhongBan();
		phtgv.setMaPhong("P1");
		phtgv.setTenPhong("Phòng hợp tác giảng viên");
		
		PhongBan pkd = new PhongBan();
		pkd.setMaPhong("P2");
		pkd.setTenPhong("Phòng kinh doanh");
		
		PhongBan pkt = new PhongBan();
		pkt.setMaPhong("P3");
		pkt.setTenPhong("Phòng kế toán");
		
		dsPhongBan.add(phtgv);
		dsPhongBan.add(pkd);
		dsPhongBan.add(pkt);
		
	
		phtgv.ThemNhanVien(new NhanVien("NV001","Nguyễn Trung Kha",FromStringToDate("12/2/2013"),
				FromStringToDate("1/1/1990")));
		phtgv.ThemNhanVien(new NhanVien("NV002","Nguyễn Văn A",FromStringToDate("1/2/2014"),
				FromStringToDate("1/6/1995")));
		pkd.ThemNhanVien(new NhanVien("NV032","Trần Văn Thanh",FromStringToDate("13/7/2015"),
				FromStringToDate("2/6/1994")));
		pkd.ThemNhanVien(new NhanVien("NV052","Lê Thị Huyền",FromStringToDate("13/7/2012"),
				FromStringToDate("2/6/1993")));
		pkt.ThemNhanVien(new NhanVien("NV075","Đỗ Văn B",FromStringToDate("1/7/2009"),
				FromStringToDate("2/6/1989")));
		pkt.ThemNhanVien(new NhanVien("NV032","Phan Văn C",FromStringToDate("3/7/2017"),
				FromStringToDate("2/6/1999")));
		for(PhongBan pb :  dsPhongBan)
			cboPhongBan.addItem(pb);
	}
	public void AddEvents()
	{
		cboPhongBan.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(cboPhongBan.getSelectedIndex()==-1)
					return;
				pbSelected = (PhongBan) cboPhongBan.getSelectedItem(); //Lấy đối tượng ra, ép kiểu về PhongBan
				listNhanVien.setListData(pbSelected.getNhanViens()); //=> Đưa dsNhanVien về Vector, ban đầu là ArrayList
			}
		});
		listNhanVien.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				if(listNhanVien.getSelectedIndex()==-1)
					return;
				nvSelected = listNhanVien.getSelectedValue();
				txtMa.setText(nvSelected.getMaNV());
				txtTen.setText(nvSelected.getTenNV());
				txtNgayVaoLam.setText(sdf.format(nvSelected.getNgayVaoLamViec()));
				txtNamSinh.setText(sdf.format(nvSelected.getNamSinh())); 				
			}
		});
		btnLuu.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				XuLiLuu();
			}
		});
		btnXoa.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				XuLiXoa();
			}
		});
		btnThoat.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0); 
			}
		});
	}
	protected void XuLiXoa() {
		// TODO Auto-generated method stub
		if(nvSelected != null)
		{
			pbSelected.getNhanViens().remove(nvSelected);
			nvSelected=null;
			listNhanVien.setListData(pbSelected.getNhanViens());
		}
	}
	protected void XuLiLuu() {
		// TODO Auto-generated method stub
		try
		{
			NhanVien nv = new NhanVien(
					txtMa.getText(),
					txtTen.getText(),
					FromStringToDate(txtNgayVaoLam.getText()),
					FromStringToDate(txtNamSinh.getText()));
			if(pbSelected!=null)
			{
				pbSelected.ThemNhanVien(nv); 
				listNhanVien.setListData(pbSelected.getNhanViens());
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null, ex.toString());
		}
	}
	public void AddControls()
	{
		Container con = getContentPane();
		JPanel pnMain = new JPanel();
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		con.add(pnMain);
		
		JPanel pnPhongBan = new JPanel();
		pnPhongBan.setLayout(new FlowLayout());
		pnMain.add(pnPhongBan);
		JLabel lblPhongBan = new JLabel("Chọn phòng ban: ");
		cboPhongBan = new JComboBox<PhongBan>();
		cboPhongBan.setPreferredSize(new Dimension(200,25)); //Width, height
		pnPhongBan.add(lblPhongBan); 
		pnPhongBan.add(cboPhongBan);
		
		JPanel pnDanhSachVaChiTiet = new JPanel();
		pnDanhSachVaChiTiet.setLayout(new GridLayout(1,2));
		pnMain.add(pnDanhSachVaChiTiet);
		
		//Làm 1 cái border quanh danh sách 
		JPanel pnDanhSach = new JPanel();
		pnDanhSach.setLayout(new BorderLayout()); //chỗ này ko thể dùng flowlayout, borderlayout sẽ ổn hơn
		Border borderDanhSach = BorderFactory.createLineBorder(Color.BLUE);
		TitledBorder titledBorderDanhSach = new TitledBorder(borderDanhSach, "Danh sách");
		titledBorderDanhSach.setTitleColor(Color.RED);
		titledBorderDanhSach.setTitleJustification(TitledBorder.CENTER);
		pnDanhSach.setBorder(titledBorderDanhSach);
		
		listNhanVien=new JList<NhanVien>();
		JScrollPane sc = new JScrollPane(listNhanVien, 	//List phải đưa vào JSCrollPane
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pnDanhSach.add(sc,BorderLayout.CENTER); //Tức là giao diện luôn được đẩy vào chính giữa khi co dãn
		pnDanhSachVaChiTiet.add(pnDanhSach); 
		
		JPanel pnChiTiet = new JPanel();
		pnChiTiet.setLayout(new BoxLayout(pnChiTiet,BoxLayout.Y_AXIS));
		
		Border borderChiTiet = BorderFactory.createLineBorder(Color.BLUE);
		TitledBorder titledBorderChiTiet = new TitledBorder(borderChiTiet, "Thông tin chi tiết");
		titledBorderChiTiet.setTitleColor(Color.RED);
		titledBorderChiTiet.setTitleJustification(TitledBorder.CENTER);
		pnChiTiet.setBorder(titledBorderChiTiet);
		
		pnDanhSachVaChiTiet.add(pnChiTiet);
		JPanel pnMa = new JPanel();
		pnMa.setLayout(new FlowLayout());
		JLabel lblMa = new JLabel("Mã: ");
		txtMa=new JTextField(15);
		pnMa.add(lblMa);
		pnMa.add(txtMa);
		pnChiTiet.add(pnMa);
		
		JPanel pnTen = new JPanel();
		pnTen.setLayout(new FlowLayout());
		JLabel lblTen = new JLabel("Tên: ");
		txtTen = new JTextField(15); //Thiết lập độ dài khung
		pnTen.add(lblTen);
		pnTen.add(txtTen);
		pnChiTiet.add(pnTen);
		
		JPanel pnNgayVaoLam = new JPanel();
		pnNgayVaoLam.setLayout(new FlowLayout());
		JLabel lblNgayVao = new JLabel("Ngày vào làm:");
		txtNgayVaoLam=new JTextField(15);
		pnNgayVaoLam.add(lblNgayVao);
		pnNgayVaoLam.add(txtNgayVaoLam);
		pnChiTiet.add(pnNgayVaoLam);
		
		JPanel pnNamSinh = new JPanel();
		pnNamSinh.setLayout(new FlowLayout());
		JLabel lblNamSinh = new JLabel("Năm sinh:");
		txtNamSinh=new JTextField(15);
		pnNamSinh.add(lblNamSinh);
		pnNamSinh.add(txtNamSinh);
		pnChiTiet.add(pnNamSinh);
		
		JPanel pnButton = new JPanel();
		
		Border borderButton = BorderFactory.createLineBorder(Color.BLUE);
		TitledBorder titledBorderButton = new TitledBorder(borderButton, "Nút tùy chọn chức năng");
		titledBorderButton.setTitleColor(Color.RED);
		titledBorderButton.setTitleJustification(TitledBorder.CENTER);
		pnButton.setBorder(titledBorderButton);
		
		pnButton.setLayout(new FlowLayout(FlowLayout.RIGHT));
		btnLuu = new JButton("Lưu");
		btnXoa = new JButton("Xóa");
		btnThoat = new JButton("Thoát");
		pnButton.add(btnLuu);
		pnButton.add(btnXoa);
		pnButton.add(btnThoat);
		pnMain.add(pnButton);
		
		//Set đều lại dựa theo ngày vào làm là lớn nhất
		lblMa.setPreferredSize(lblNgayVao.getPreferredSize());
		lblTen.setPreferredSize(lblNgayVao.getPreferredSize());
		lblNamSinh.setPreferredSize(lblNgayVao.getPreferredSize()); 
	
		
	}
	public void ShowWindows()
	{  
		this.setSize(550,350);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
}
