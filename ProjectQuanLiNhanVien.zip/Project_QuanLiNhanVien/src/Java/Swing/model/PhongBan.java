package Java.Swing.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Vector;

public class PhongBan implements Serializable{
	private String maPhong;
	private String tenPhong;
	Vector<NhanVien> nhanViens;
	
	public void ThemNhanVien(NhanVien nv)
	{
		this.nhanViens.add(nv);
		nv.setPhong(this); //Đẩy 1 nhân viên vào 1 phòng ban
	}
	
	public String getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(String maPhong) {
		this.maPhong = maPhong;
	}
	public String getTenPhong() {
		return tenPhong;
	}
	public void setTenPhong(String tenPhong) {
		this.tenPhong = tenPhong;
	}
	public Vector<NhanVien> getNhanViens() {
		return nhanViens;
	}
	public void setNhanViens(Vector<NhanVien> nhanViens) {
		this.nhanViens = nhanViens;
	}
//	public PhongBan(String maPhong, String tenPhong, ArrayList<NhanVien> nhanViens) {
//		super();
//		this.maPhong = maPhong;
//		this.tenPhong = tenPhong;
//		this.nhanViens = nhanViens;
//	}
	public PhongBan() {
		super();
		this.nhanViens=new Vector<NhanVien>();
	}
	@Override
	public String toString() {
		return this.tenPhong;
	}
}
